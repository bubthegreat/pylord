@echo off
cls
if exist %1\lord.exe goto begin
if not exist %1\lord.exe goto nodir
:nodir
echo.
echo                      -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
echo                       DeAtH lOrD Version 1.9,  VASoft
echo                      -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
echo                        By: \/ade 79  (SHOUPJ on AOL)
echo.
echo *Usage*
echo install  -=directory where LORD is=-
echo.
echo *Example*
echo install.bat c:\ra\doors\lord (no trailing backslash)
echo.
echo.
goto finish3

:begin
echo.
echo                      -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
echo                       DeAtH lOrD Version 1.9,  VASoft
echo                      -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
echo                        By: \/ade 79  (SHOUPJ on AOL)
echo.
echo.
echo.
choice /c:123x What Version of L.O.R.D Do You Have: 1=3.26 2=3.26a 3=3.50 x=exit? 
if errorlevel 4 goto finish3
if errorlevel 3 goto 350
if errorlevel 2 goto 326
if errorlevel 1 goto 326


:326
choice /c:yn Do You Have Other Places? 
if errorlevel 2 goto 3262
if errorlevel 1 goto 3263

:350
echo Now backing up files...
if not exist %1\lenemy.old goto bb1
del %1\lenemy.old
:bb1
if not exist %1\lordtxt.old goto cc1
del %1\lordtxt.old
:cc1
ren %1\lenemy.dat lenemy.old
ren %1\lordtxt.dat lordtxt.old
echo Files have been backed up...
echo.
echo.
echo.
echo Installing new files...
copy info1 %1\lenemy.dat
copy info2 %1\lordtxt.dat
copy info3 %1\bar.txt
copy info7 %1\badsay.dat
copy info8 %1\lognow.txt
copy info9 %1\normsay.dat
copy death.txt %1\deathlrd.txt
copy uninstal.bat %1\uninstal.bat
echo.
echo DeAtH lOrD is installed...
echo.
pause
cls
echo Installation complete!
echo To uninstall DeAtH lOrD, simply run uninstal.bat from your LORD directory.
echo Thanks for trying DeAtH lOrD, a LORD add-on by \/ade 79.
echo Send me any Q&A's or comments to: SHOUPJ on AOL.
echo Please view the Death.txt file for more info on this program.
echo.
echo.
echo.
choice /c:yn Would you like to view the readme file now? 
if errorlevel 2 goto finish2
if errorlevel 1 goto yes

:3262
echo Now backing up files...
if not exist %1\lenemy.old goto bb2
del %1\lenemy.old
:bb2
if not exist %1\lordtxt.old goto cc2
del %1\lordtxt.old
:cc2
ren %1\lenemy.dat lenemy.old
ren %1\lordtxt.dat lordtxt.old
echo Files have been backed up...
echo.
echo.
echo.
echo Installing new files...
copy info1 %1\lenemy.dat
copy info4 %1\lordtxt.dat
copy info3 %1\bar.txt
copy info7 %1\badsay.dat
copy info8 %1\lognow.txt
copy info9 %1\normsay.dat
copy death.txt %1\deathlrd.txt
copy uninstal.bat %1\uninstal.bat
echo.
echo Files installed...
echo.
pause
cls
echo Installation complete!
echo To uninstall DeAtH lOrD, simply run uninstal.bat from your LORD directory.
echo Thanks for trying DeAtH lOrD, a LORD add-on by \/ade 79.
echo Send me any Q&A's or comments to: SHOUPJ on AOL.
echo Please view the Death.txt file for more info on this program.
echo.
echo.
choice /c:yn Would you like to view the readme file now? 
if errorlevel 2 goto finish2
if errorlevel 1 goto yes

:3263
echo Now backing up files...
if not exist %1\lenemy.old goto bb3
del %1\lenemy.old
:bb3
if not exist %1\lordtxt.old goto cc3
del %1\lordtxt.old
:cc3
ren %1\lenemy.dat lenemy.old
ren %1\lordtxt.dat lordtxt.old
echo Files have been backed up...
echo.
echo.
echo.
echo Installing new files...
copy info1 %1\lenemy.dat
copy info5 %1\lordtxt.dat
copy info3 %1\bar.txt
copy info7 %1\badsay.dat
copy info8 %1\lognow.txt
copy info9 %1\normsay.dat
copy death.txt %1\deathlrd.txt
copy uninstal.bat %1\uninstal.bat
echo.
echo Files installed...
echo.
pause
cls
echo Installation complete!
echo To uninstall DeAtH lOrD, simply run uninstal.bat from your LORD directory.
echo Thanks for trying DeAtH lOrD, a LORD add-on by \/ade 79.
echo Send me any Q&A's or comments to: SHOUPJ on AOL.
echo Please view the Death.txt file for more info on this program.
echo.
echo.
echo.
choice /c:yn Would you like to view the readme file now? 
if errorlevel 2 goto finish2
if errorlevel 1 goto yes

:yes
cls
echo DeAtH lOrD is a new product from VASoft and
echo Thee Will Be More Like It, If you have any
echo Questions or comment's mail me at 'SHOUPJ'
echo on AOL, Look for more products from \/ade.
echo.
pause

:finish2
cls
echo.
echo            -=-=-=-=-=-=-=-=-=-=-
echo             DeAtH lOrD:  VASoft
echo            -=-=-=-=-=-=-=-=-=-=-
echo         By: \/ade 79 (SHOUPJ on AOL)
echo.

:finish3
echo.

