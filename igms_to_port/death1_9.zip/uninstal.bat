@echo off
cls
if not exist lord.exe goto badend
echo.
echo            -=-=-=-=-=-=-=-=-=-=-
echo             DeAtH lOrD:  VASoft
echo            -=-=-=-=-=-=-=-=-=-=-
echo         By: \/ade 79 (SHOUPJ on AOL)
echo.
echo.
echo.
echo.
echo.
pause
cls
echo Deleting DeAtH lOrD...
del lordtxt.dat
del lenemy.dat
echo.
echo DeAtH lOrD files deleted...
echo.
echo Putting the original LORD back...
ren lordtxt.old lordtxt.dat
ren lenemy.old lenemy.dat
echo.
echo Uninstallation of DeAtH lOrD complete! I hope you and your callers
echo enjoyed it! This is version 1.7 of DeAtH LoRd.
echo I am releasing this as FREEWARE.
goto end

:badend
echo You must run this program from your LORD directory!
echo.

:end
echo.
