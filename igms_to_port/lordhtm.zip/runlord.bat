c:
cd \bbs\doors\lord
topten %2 %3 %4
ftp -n -i www3.sk.sympatico.ca < ftppost
lord2htm
call start %1
topten
lord2htm
ftp -n -i www3.sk.sympatico.ca < ftppost
