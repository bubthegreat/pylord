These two files generate html pages based on today's news and yesterday's new
files in LORD.

LORD2HTM.EXE uses no command line parameters and generates
LOGNOW.HTM and LOGOLD.HTM.  

TOPTEN.EXE is misnamed but hey, what can I say... :-)
TOPTEN.EXE generates a players listing (LORDRANK.HTM) from the player.dat
file and supports exactly one command line parameter - the user name of one
player you want marked as on

ex: TOPTEN Stephen hurd

Should be exactly as it would appear in the drop file assuming a space between
first and last names.  Not case sensetive.

If no player is listed then it just uses the info in player.dat.

I've included the QuickBasic source and the batch file I use to run LORD...
the batch file automatically updates the web pages when you enter and exit
LORD.

Both runlord.bat and ftppost should be modified for your system.

Both LOGNOW.HTM and LORDRANK.HTM auto-refresh every 60 seconds.

LEGAL crap.
        This is FreeWare.  You have the source.  If it breaks, fix it.  I make
        no guarantee's whatsoever but do say that it seems to work for me.

You can reach me at deuce@net1fx.com or shurd@sk.sympatico.ca

